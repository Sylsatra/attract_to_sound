package su.plo.voice.client.audio.source

import net.minecraft.client.Minecraft
import net.minecraft.world.entity.player.Player
import net.minecraft.world.phys.Vec3
import su.plo.config.entry.BooleanConfigEntry
import su.plo.config.entry.DoubleConfigEntry
import su.plo.lib.mod.extensions.eyePosition
import su.plo.voice.api.client.config.OverlappingSourceTypes
import su.plo.voice.client.BaseVoiceClient
import su.plo.voice.client.config.VoiceClientConfig
import su.plo.voice.proto.data.audio.source.PlayerSourceInfo
import su.plo.voice.proto.packets.tcp.clientbound.SourceAudioEndPacket
import su.plo.voice.proto.packets.udp.clientbound.SourceAudioPacket

class ClientPlayerSource(
    voiceClient: BaseVoiceClient,
    config: VoiceClientConfig,
    sourceInfo: PlayerSourceInfo
) : BaseClientAudioSource<PlayerSourceInfo>(voiceClient, config, sourceInfo) {

    override var sourceVolume: DoubleConfigEntry = config.voice
        .volumes
        .getPlayerVolume(sourceInfo.playerInfo.playerId)

    override fun process(packet: SourceAudioPacket) {
        if (sourceMute.value()) return
        super.process(packet)
    }

    override fun process(packet: SourceAudioEndPacket) {
        if (sourceMute.value()) return
        super.process(packet)
    }

    override fun getPosition(): Vec3 =
        sourcePlayer?.eyePosition() ?: Vec3.ZERO

    override fun getLookAngle(): Vec3 =
        sourcePlayer?.lookAngle ?: Vec3.ZERO

    override fun isPanningDisabled(): Boolean =
        sourcePlayer == getListener() || super.isPanningDisabled()

    override fun shouldWrite(): Boolean {
        if (voiceClient.config.advanced.sourceTypesOverlap.value() == OverlappingSourceTypes.MUTE_PROXIMITY) {
            return voiceClient.sourceManager.sources
                .filterIsInstance<ClientDirectSource>()
                .filter { it.isActivated() }
                .none { it.sourceInfo.sender?.id == sourceInfo.playerInfo.playerId }
        }

        return true
    }

    private val sourceMute: BooleanConfigEntry
        get() {
            return config.voice
                .volumes
                .getPlayerMute(sourceInfo.playerInfo.playerId)
        }

    private val sourcePlayer: Player?
        get() {
            return Minecraft.getInstance().level?.getPlayerByUUID(sourceInfo.playerInfo.playerId)
        }
}
