package su.plo.voice.client.audio.device;

import org.jetbrains.annotations.NotNull;
import org.lwjgl.openal.AL11;
import org.lwjgl.openal.ALC10;
import org.lwjgl.openal.ALC11;
import su.plo.slib.api.logging.McLogger;
import su.plo.voice.BaseVoice;
import su.plo.voice.api.client.PlasmoVoiceClient;
import su.plo.voice.api.client.audio.device.DeviceException;
import su.plo.voice.api.client.audio.device.InputDevice;
import su.plo.voice.api.client.event.audio.device.DeviceClosedEvent;
import su.plo.voice.api.client.event.audio.device.DeviceOpenEvent;
import su.plo.voice.api.client.event.audio.device.DevicePreOpenEvent;
import su.plo.voice.api.util.AudioUtil;
import su.plo.voice.client.audio.AlUtil;

import javax.sound.sampled.AudioFormat;

public final class AlInputDevice extends BaseAudioDevice implements InputDevice {

    private static final McLogger LOGGER = BaseVoice.createLogger("AlInputDevice");

    private volatile long devicePointer;
    private boolean hasDisconnectEXT;

    private volatile boolean started = false;
    private volatile boolean disconnected = false;

    private int captureChannels;
    private boolean downmixToMono;

    public AlInputDevice(PlasmoVoiceClient client,
                         @NotNull String name,
                         @NotNull AudioFormat format) throws DeviceException {
        super(client, name, format);
        open();
    }

    @Override
    public synchronized void close() {
        if (isOpen()) {
            stop();

            long devicePointer = this.devicePointer;
            this.devicePointer = 0L;

            ALC11.alcCaptureCloseDevice(devicePointer);

            LOGGER.info("Device {} closed", getName());
        } else if (disconnected) {
            this.devicePointer = 0L;
            LOGGER.info("Device {} closed", getName());
        }

        getVoiceClient().getEventBus().fire(new DeviceClosedEvent(this));
    }

    @Override
    public boolean isOpen() {
        if (devicePointer != 0L && (hasDisconnectEXT && ALC11.alcGetInteger(devicePointer, 787) == 0) && !disconnected) {
            this.disconnected = true;
        }

        return devicePointer != 0L && !disconnected;
    }

    @Override
    public synchronized void start() {
        if (!isOpen() || started) return;

        ALC11.alcCaptureStart(devicePointer);
        if (AlUtil.checkAlcErrors(devicePointer, "Start device")) return;

        this.started = true;
    }

    @Override
    public synchronized void stop() {
        if (!isOpen() || !started) return;

        ALC11.alcCaptureStop(devicePointer);
        AlUtil.checkAlcErrors(devicePointer, "Stop capture device");
        started = false;

        int available = available();
        short[] data = new short[available * captureChannels];
        ALC11.alcCaptureSamples(devicePointer, data, available);
        AlUtil.checkAlcErrors(devicePointer, "Capture available samples");
    }

    @Override
    public int available() {
        if (!isOpen() || !started) return 0;

        int samples = ALC11.alcGetInteger(devicePointer, ALC11.ALC_CAPTURE_SAMPLES);
        AlUtil.checkAlcErrors(devicePointer, "Get available samples count");

        return samples;
    }

    @Override
    public boolean isStarted() {
        return started;
    }

    @Override
    public short[] read(int frameSize) {
        if (!isOpen() || frameSize > available()) return null;

        short[] shorts = new short[frameSize * captureChannels];
        ALC11.alcCaptureSamples(devicePointer, shorts, frameSize);
        AlUtil.checkAlcErrors(devicePointer, "Capture samples");

        return downmixToMono ? AudioUtil.convertToMonoShorts(shorts) : shorts;
    }

    @Override
    protected synchronized void open() throws DeviceException {
        if (isOpen()) throw new DeviceException("Device is already open");

        DevicePreOpenEvent preOpenEvent = new DevicePreOpenEvent(this);
        getVoiceClient().getEventBus().fire(preOpenEvent);

        if (preOpenEvent.isCancelled()) {
            throw new DeviceException("Device opening has been canceled");
        }

        this.devicePointer = openDevice();
        this.disconnected = false;

        this.hasDisconnectEXT = ALC10.alcIsExtensionPresent(devicePointer, "ALC_EXT_disconnect");

        LOGGER.info("Device {} initialized", getName());
        getVoiceClient().getEventBus().fire(new DeviceOpenEvent(this));
    }

    private long openDevice() throws DeviceException {
        AudioFormat format = getFormat();
        String deviceName = getName();

        int channels = format.getChannels();
        this.captureChannels = (channels == 1 && AlUtil.isCaptureMonoDownmixBroken()) ? 2 : channels;
        this.downmixToMono = captureChannels != channels;

        if (downmixToMono) {
            LOGGER.info("Working around broken OpenAL Soft mono capture, capturing {} in stereo", deviceName);
        }

        int alFormat = captureChannels == 2 ? AL11.AL_FORMAT_STEREO16 : AL11.AL_FORMAT_MONO16;

        long devicePointer = ALC11.alcCaptureOpenDevice(deviceName, (int) format.getSampleRate(), alFormat, getFrameSize());

        if (devicePointer == 0L) {
            AlUtil.checkAlcErrors(0L, "Open capture device");
            throw new DeviceException("Failed to open OpenAL device");
        }

        if (AlUtil.checkAlcErrors(devicePointer, "Open capture device")) {
            ALC11.alcCaptureCloseDevice(devicePointer);
            throw new DeviceException("Failed to open OpenAL device");
        }

        return devicePointer;
    }
}
