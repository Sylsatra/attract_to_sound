package su.plo.lib.mod.client.gui.widget;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;
import su.plo.lib.mod.client.Inputs;
import su.plo.lib.mod.client.render.Colors;
import su.plo.lib.mod.client.render.gui.GuiRenderContext;
import su.plo.slib.api.chat.component.McTextComponent;
import lombok.Getter;
import lombok.Setter;
import org.jetbrains.annotations.NotNull;
import su.plo.lib.mod.client.gui.narration.NarrationOutput;

import java.awt.Color;

public abstract class GuiAbstractWidget implements GuiWidget, GuiNarrationWidget, GuiWidgetListener {

    public static McTextComponent wrapDefaultNarrationMessage(McTextComponent component) {
        return McTextComponent.translatable("gui.narrate.button", component);
    }

    @Getter
    @Setter
    protected int x;
    @Getter
    @Setter
    protected int y;

    @Getter
    @Setter
    protected int width;
    @Getter
    @Setter
    protected int height;

    @Setter
    protected McTextComponent text;
    protected float alpha = 1F;

    @Getter
    protected boolean hovered;
    @Getter
    @Setter
    protected boolean active = true;
    @Getter
    @Setter
    protected boolean visible = true;

    @Getter
    private boolean focused;

    public GuiAbstractWidget(int x,
                             int y,
                             int width,
                             int height) {
        this(x, y, width, height, McTextComponent.empty());
    }

    public GuiAbstractWidget(int x,
                             int y,
                             int width,
                             int height,
                             @NotNull McTextComponent text) {
        this.x = x;
        this.y = y;

        this.width = width;
        this.height = height;

        this.text = text;
    }

    // GuiWidget impl
    @Override
    public void render(@NotNull GuiRenderContext context, int mouseX, int mouseY, float delta) {
        if (!visible) return;

        this.hovered = isHovered(mouseX, mouseY);
        renderButton(context, mouseX, mouseY, delta);
    }

    // GuiNarratableWidget impl
    @Override
    public NarrationPriority narrationPriority() {
        if (this.focused) {
            return NarrationPriority.FOCUSED;
        } else {
            return hovered ? NarrationPriority.HOVERED : NarrationPriority.NONE;
        }
    }

    @Override
    public void updateNarration(@NotNull NarrationOutput narrationOutput) {
        defaultButtonNarrationText(narrationOutput);
    }

    // GuiWidgetEventListener impl
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!active || !visible || !isValidClickButton(button)) return false;

        if (isClicked(mouseX, mouseY)) {
            playDownSound();
            onClick(mouseX, mouseY);
            return true;
        }

        return false;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (isValidClickButton(button)) {
            onRelease(mouseX, mouseY);
            return true;
        }

        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (isValidClickButton(button)) {
            onDrag(mouseX, mouseY, deltaX, deltaY);
            return true;
        }

        return false;
    }

    @Override
    public boolean changeFocus(boolean lookForwards) {
        if (!active || !visible) return false;

        return !focused;
    }

    @Override
    public void applyFocus(boolean focused) {
        this.focused = focused;
    }

    @Override
    public boolean isMouseOver(double mouseX, double mouseY) {
        return active && visible && isHovered(mouseX, mouseY);
    }

    // Class methods
    public void renderButton(@NotNull GuiRenderContext context, int mouseX, int mouseY, float delta) {
        GuiWidgetTexture sprite = getButtonTexture(isHoveredOrFocused());

        context.blitSprite(sprite, x, y, 0, 0, width / 2, height);
        context.blitSprite(sprite, x + width / 2, y, sprite.getSpriteWidth() - width / 2, 0, width / 2, height);

        renderBackground(context, mouseX, mouseY);

        renderText(context, mouseX, mouseY);
    }

    public void renderToolTip(@NotNull GuiRenderContext context, int mouseX, int mouseY) {
    }

    public void onClick(double mouseX, double mouseY) {
    }

    public void onRelease(double mouseX, double mouseY) {
    }

    public void onDrag(double mouseX, double mouseY, double deltaX, double deltaY) {
    }

    public McTextComponent getText() {
        return text;
    }

    public boolean isHoveredOrFocused() {
        return hovered || (focused && Inputs.isLastInputKeyboard());
    }

    protected void renderBackground(@NotNull GuiRenderContext context, int mouseX, int mouseY) {
    }

    protected void renderText(@NotNull GuiRenderContext context, int mouseX, int mouseY) {
        Color textColor = Colors.withAlpha(active ? Colors.WHITE : Colors.GRAY, alpha);

        context.drawCenteredString(
                getText(),
                x + width / 2,
                y + (height - 8) / 2,
                textColor
        );
    }

    protected void playDownSound() {
        SoundManager soundManager = Minecraft.getInstance().getSoundManager();
        soundManager.play(
                SimpleSoundInstance.forUI(
                        //#if MC>=11903
                        SoundEvents.UI_BUTTON_CLICK.value(),
                        //#else
                        //$$ SoundEvents.UI_BUTTON_CLICK,
                        //#endif
                        1.0f,
                        0.25f
                )
        );
    }

    protected void defaultButtonNarrationText(NarrationOutput narrationElementOutput) {
        narrationElementOutput.add(NarrationOutput.Type.TITLE, createNarrationMessage());
        if (active) {
            if (isFocused()) {
                narrationElementOutput.add(NarrationOutput.Type.USAGE, McTextComponent.translatable("narration.button.usage.focused"));
            } else {
                narrationElementOutput.add(NarrationOutput.Type.USAGE, McTextComponent.translatable("narration.button.usage.hovered"));
            }
        }
    }

    protected McTextComponent createNarrationMessage() {
        return wrapDefaultNarrationMessage(getText());
    }

    protected @NotNull GuiWidgetTexture getButtonTexture(boolean hovered) {
        if (!this.active) {
            return GuiWidgetTexture.BUTTON_DISABLED;
        } else if (hovered) {
            return GuiWidgetTexture.BUTTON_ACTIVE;
        }

        return GuiWidgetTexture.BUTTON_DEFAULT;
    }

    protected boolean isValidClickButton(int button) {
        return button == GLFW.GLFW_MOUSE_BUTTON_1;
    }

    protected boolean isClicked(double mouseX, double mouseY) {
        return isMouseOver(mouseX, mouseY);
    }

    protected boolean isHovered(double mouseX, double mouseY) {
        return mouseX >= x && mouseY >= y &&
                mouseX < x + width &&
                mouseY < y + height;
    }
}
