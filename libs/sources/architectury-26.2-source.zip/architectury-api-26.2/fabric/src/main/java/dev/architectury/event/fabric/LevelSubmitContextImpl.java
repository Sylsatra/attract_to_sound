/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.event.fabric;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.architectury.event.events.client.ClientLevelRenderEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.renderer.SubmitNodeCollector;

@Environment(EnvType.CLIENT)
final class LevelSubmitContextImpl extends LevelRenderContextImpl implements ClientLevelRenderEvent.SubmitContext {
    private final LevelRenderContext context;

    LevelSubmitContextImpl(LevelRenderContext context) {
        super(context);
        this.context = context;
    }

    @Override
    public PoseStack poseStack() {
        return context.poseStack();
    }

    @Override
    public SubmitNodeCollector submitNodeCollector() {
        return context.submitNodeCollector();
    }
}
