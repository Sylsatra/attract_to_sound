/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.event.neoforge;

import com.mojang.brigadier.CommandDispatcher;
import dev.architectury.event.CompoundEventResult;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.client.*;
import dev.architectury.event.events.client.ClientChatEvent;
import dev.architectury.event.events.common.InteractionEvent;
import dev.architectury.impl.ScreenAccessImpl;
import dev.architectury.impl.TooltipEventPositionContextImpl;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.*;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.lifecycle.ClientStartedEvent;
import net.neoforged.neoforge.client.event.lifecycle.ClientStoppingEvent;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.LevelEvent;

@EventBusSubscriber(modid = "architectury", value = Dist.CLIENT)
public class EventHandlerImplClient {
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ItemTooltipEvent event) {
        ClientTooltipEvent.ITEM.invoker().append(event.getItemStack(), event.getToolTip(), event.getContext(), event.getFlags());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ClientTickEvent.Pre event) {
        dev.architectury.event.events.client.ClientTickEvent.CLIENT_PRE.invoker().tick(Minecraft.getInstance());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ClientTickEvent.Post event) {
        dev.architectury.event.events.client.ClientTickEvent.CLIENT_POST.invoker().tick(Minecraft.getInstance());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventRenderGameOverlayEvent(RenderGuiEvent.Post event) {
        ClientGuiEvent.RENDER_HUD.invoker().renderHud(event.getGuiGraphics(), event.getPartialTick());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ClientPlayerNetworkEvent.LoggingIn event) {
        ClientPlayerEvent.CLIENT_PLAYER_JOIN.invoker().join(event.getPlayer());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientPlayerEvent.CLIENT_PLAYER_QUIT.invoker().quit(event.getPlayer());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ClientPlayerNetworkEvent.Clone event) {
        ClientPlayerEvent.CLIENT_PLAYER_RESPAWN.invoker().respawn(event.getOldPlayer(), event.getNewPlayer());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventInitScreenEvent(ScreenEvent.Init.Pre event) {
        if (ClientGuiEvent.INIT_PRE.invoker().init(event.getScreen(), new ScreenAccessImpl(event.getScreen())).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventInitScreenEvent(ScreenEvent.Init.Post event) {
        ClientGuiEvent.INIT_POST.invoker().init(event.getScreen(), new ScreenAccessImpl(event.getScreen()));
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(net.neoforged.neoforge.client.event.ClientChatEvent event) {
        EventResult process = ClientChatEvent.SEND.invoker().send(event.getMessage(), null);
        if (process.isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ClientChatReceivedEvent.Player event) {
        CompoundEventResult<Component> process = ClientChatEvent.RECEIVED.invoker().process(event.getBoundChatType(), event.getMessage());
        if (process.isPresent()) {
            if (process.isFalse())
                event.setCanceled(true);
            else if (process.object() != null)
                event.setMessage(process.object());
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ClientChatReceivedEvent.System event) {
        CompoundEventResult<Component> process = ClientSystemMessageEvent.RECEIVED.invoker().process(event.getMessage());
        if (process.isPresent()) {
            if (process.isFalse())
                event.setCanceled(true);
            else if (process.object() != null)
                event.setMessage(process.object());
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventWorldEvent(LevelEvent.Load event) {
        if (event.getLevel().isClientSide()) {
            ClientLevel world = (ClientLevel) event.getLevel();
            ClientLifecycleEvent.CLIENT_LEVEL_LOAD.invoker().act(world);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ScreenEvent.Opening event) {
        CompoundEventResult<Screen> result = ClientGuiEvent.SET_SCREEN.invoker().modifyScreen(event.getScreen());
        if (result.isPresent()) {
            if (result.isFalse())
                event.setCanceled(true);
            else if (result.object() != null)
                event.setNewScreen(result.object());
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventDrawScreenEvent(ScreenEvent.Render.Pre event) {
        if (ClientGuiEvent.RENDER_PRE.invoker().render(event.getScreen(), event.getGuiGraphics(), event.getMouseX(), event.getMouseY(), event.getPartialTick()).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventDrawScreenEvent(ScreenEvent.Render.Post event) {
        ClientGuiEvent.RENDER_POST.invoker().render(event.getScreen(), event.getGuiGraphics(), event.getMouseX(), event.getMouseY(), event.getPartialTick());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventDrawScreenEvent(ScreenEvent.Render.Background event) {
        ClientGuiEvent.RENDER_BACKGROUND.invoker().render(event.getScreen(), event.getGuiGraphics(), event.getMouseX(), event.getMouseY(), event.getPartialTick());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ScreenEvent.Closing event) {
        ClientGuiEvent.SCREEN_CLOSING.invoker().closing(event.getScreen());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventPlayerInteractEvent(PlayerInteractEvent.RightClickEmpty event) {
        InteractionEvent.CLIENT_RIGHT_CLICK_AIR.invoker().click(event.getEntity(), event.getHand());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventPlayerInteractEvent(PlayerInteractEvent.LeftClickEmpty event) {
        InteractionEvent.CLIENT_LEFT_CLICK_AIR.invoker().click(event.getEntity(), event.getHand());
    }
    
    private static final ThreadLocal<TooltipEventPositionContextImpl> tooltipPositionContext = ThreadLocal.withInitial(TooltipEventPositionContextImpl::new);
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventRenderTooltipEvent(RenderTooltipEvent.Pre event) {
        GuiGraphicsExtractor graphics = event.getGraphics();
        ClientTooltipEvent.additionalContexts().setItem(event.getItemStack());
        
        try {
            if (ClientTooltipEvent.RENDER_PRE.invoker().renderTooltip(graphics, event.getComponents(), event.getX(), event.getY()).isFalse()) {
                event.setCanceled(true);
                return;
            }
            
            TooltipEventPositionContextImpl positionContext = tooltipPositionContext.get();
            positionContext.reset(event.getX(), event.getY());
            ClientTooltipEvent.RENDER_MODIFY_POSITION.invoker().renderTooltip(graphics, positionContext);
            event.setX(positionContext.getTooltipX());
            event.setY(positionContext.getTooltipY());
        } finally {
            ClientTooltipEvent.additionalContexts().setItem(null);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventMouseScrollEvent(ScreenEvent.MouseScrolled.Pre event) {
        if (ClientScreenInputEvent.MOUSE_SCROLLED_PRE.invoker().mouseScrolled(Minecraft.getInstance(), event.getScreen(), event.getMouseX(), event.getMouseY(), event.getScrollDeltaX(), event.getScrollDeltaY()).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventMouseScrollEvent(ScreenEvent.MouseScrolled.Post event) {
        ClientScreenInputEvent.MOUSE_SCROLLED_POST.invoker().mouseScrolled(Minecraft.getInstance(), event.getScreen(), event.getMouseX(), event.getMouseY(), event.getScrollDeltaX(), event.getScrollDeltaY());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventMouseClickedEvent(ScreenEvent.MouseButtonPressed.Pre event) {
        if (ClientScreenInputEvent.MOUSE_CLICKED_PRE.invoker().mouseClicked(Minecraft.getInstance(), event.getScreen(), event.getMouseButtonEvent(), event.isDoubleClick()).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventMouseClickedEvent(ScreenEvent.MouseButtonPressed.Post event) {
        ClientScreenInputEvent.MOUSE_CLICKED_POST.invoker().mouseClicked(Minecraft.getInstance(), event.getScreen(), event.getMouseButtonEvent(), event.isDoubleClick());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventMouseDragEvent(ScreenEvent.MouseDragged.Pre event) {
        if (ClientScreenInputEvent.MOUSE_DRAGGED_PRE.invoker().mouseDragged(Minecraft.getInstance(), event.getScreen(), event.getMouseButtonEvent(), event.getDragX(), event.getDragY()).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventMouseDragEvent(ScreenEvent.MouseDragged.Post event) {
        ClientScreenInputEvent.MOUSE_DRAGGED_POST.invoker().mouseDragged(Minecraft.getInstance(), event.getScreen(), event.getMouseButtonEvent(), event.getDragX(), event.getDragY());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventMouseReleasedEvent(ScreenEvent.MouseButtonReleased.Pre event) {
        if (ClientScreenInputEvent.MOUSE_RELEASED_PRE.invoker().mouseReleased(Minecraft.getInstance(), event.getScreen(), event.getMouseButtonEvent()).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventMouseReleasedEvent(ScreenEvent.MouseButtonReleased.Post event) {
        ClientScreenInputEvent.MOUSE_RELEASED_POST.invoker().mouseReleased(Minecraft.getInstance(), event.getScreen(), event.getMouseButtonEvent());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventKeyboardCharTypedEvent(ScreenEvent.CharacterTyped.Pre event) {
        if (ClientScreenInputEvent.CHAR_TYPED_PRE.invoker().charTyped(Minecraft.getInstance(), event.getScreen(), event.getCharacterEvent()).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventKeyboardCharTypedEvent(ScreenEvent.CharacterTyped.Post event) {
        ClientScreenInputEvent.CHAR_TYPED_POST.invoker().charTyped(Minecraft.getInstance(), event.getScreen(), event.getCharacterEvent());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventKeyboardKeyPressedEvent(ScreenEvent.KeyPressed.Pre event) {
        if (ClientScreenInputEvent.KEY_PRESSED_PRE.invoker().keyPressed(Minecraft.getInstance(), event.getScreen(), event.getKeyEvent()).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventKeyboardKeyPressedEvent(ScreenEvent.KeyPressed.Post event) {
        ClientScreenInputEvent.KEY_PRESSED_POST.invoker().keyPressed(Minecraft.getInstance(), event.getScreen(), event.getKeyEvent());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventKeyboardKeyReleasedEvent(ScreenEvent.KeyReleased.Pre event) {
        if (ClientScreenInputEvent.KEY_RELEASED_PRE.invoker().keyReleased(Minecraft.getInstance(), event.getScreen(), event.getKeyEvent()).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventKeyboardKeyReleasedEvent(ScreenEvent.KeyReleased.Post event) {
        ClientScreenInputEvent.KEY_RELEASED_POST.invoker().keyReleased(Minecraft.getInstance(), event.getScreen(), event.getKeyEvent());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventInputEvent(InputEvent.MouseScrollingEvent event) {
        if (ClientRawInputEvent.MOUSE_SCROLLED.invoker().mouseScrolled(Minecraft.getInstance(), event.getScrollDeltaX(), event.getScrollDeltaY()).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventInputEvent(InputEvent.MouseButton.Pre event) {
        if (ClientRawInputEvent.MOUSE_CLICKED_PRE.invoker().mouseClicked(Minecraft.getInstance(), event.getMouseButtonInfo(), event.getAction()).isFalse()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventInputEvent(InputEvent.MouseButton.Post event) {
        ClientRawInputEvent.MOUSE_CLICKED_POST.invoker().mouseClicked(Minecraft.getInstance(), event.getMouseButtonInfo(), event.getAction());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void eventInputEvent(InputEvent.Key event) {
        ClientRawInputEvent.KEY_PRESSED.invoker().keyPressed(Minecraft.getInstance(), event.getAction(), event.getKeyEvent());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(RegisterClientCommandsEvent event) {
        ClientCommandRegistrationEvent.EVENT.invoker().register((CommandDispatcher<ClientCommandRegistrationEvent.ClientCommandSourceStack>)
                (CommandDispatcher<?>) event.getDispatcher(), event.getBuildContext());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ExtractLevelRenderStateEvent event) {
        ClientLevelRenderEvent.END_EXTRACTION.invoker().extract(new LevelExtractionContextImpl(event));
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(RenderLevelStageEvent.AfterOpaqueBlocks event) {
        ClientLevelRenderEvent.AFTER_OPAQUE_BLOCKS.invoker().render(new LevelStageContextImpl(event));
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(SubmitCustomGeometryEvent event) {
        ClientLevelRenderEvent.COLLECT_SUBMITS.invoker().collectSubmits(new LevelSubmitContextImpl(event));
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(RenderLevelStageEvent.AfterOpaqueFeatures event) {
        ClientLevelRenderEvent.AFTER_OPAQUE_FEATURES.invoker().render(new LevelStageContextImpl(event));
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(RenderLevelStageEvent.AfterTranslucentFeatures event) {
        ClientLevelRenderEvent.AFTER_TRANSLUCENT_FEATURES.invoker().render(new LevelStageContextImpl(event));
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(RenderLevelStageEvent.AfterTranslucentBlocks event) {
        ClientLevelRenderEvent.AFTER_TRANSLUCENT_BLOCKS.invoker().render(new LevelStageContextImpl(event));
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(RenderLevelStageEvent.AfterTranslucentParticles event) {
        ClientLevelRenderEvent.AFTER_TRANSLUCENT_PARTICLES.invoker().render(new LevelStageContextImpl(event));
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ClientStartedEvent event) {
        ClientLifecycleEvent.CLIENT_STARTED.invoker().stateChanged(event.getClient());
    }
    
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void event(ClientStoppingEvent event) {
        ClientLifecycleEvent.CLIENT_STOPPING.invoker().stateChanged(event.getClient());
    }
    
    @EventBusSubscriber(modid = "architectury", value = Dist.CLIENT)
    public static class ModBasedEventHandler {
        // @SubscribeEvent(priority = EventPriority.HIGH)
        // public static void eventTextureStitchEvent(TextureStitchEvent.Post event) {
        // ClientTextureStitchEvent.POST.invoker().stitch(event.getAtlas());
        // }
        
        @SubscribeEvent(priority = EventPriority.HIGH)
        public static void event(FMLClientSetupEvent event) {
            ClientLifecycleEvent.CLIENT_SETUP.invoker().stateChanged(Minecraft.getInstance());
        }
    }
}
