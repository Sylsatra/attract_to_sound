package com.geckolib.model;

import com.geckolib.animatable.GeoAnimatable;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

import java.util.Objects;

/// [DefaultedGeoModel] specific to [Blocks][net.minecraft.world.level.block.Block]
///
/// Using this class pre-sorts provided asset paths into the "block" subdirectory
public class DefaultedBlockGeoModel<T extends GeoAnimatable> extends DefaultedGeoModel<T> {
	/// Create a new instance of this model class with no asset subpath
	///
	/// The resultant asset id will be named from your [BlockEntityType]'s registered id<br/>
	public <B extends BlockEntity & GeoAnimatable> DefaultedBlockGeoModel(BlockEntityType<B> blockEntityType) {
		this(Objects.requireNonNull(BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(blockEntityType)));
	}
	/// Create a new instance of this model class
	///
	/// The asset path should be the truncated relative path from the base folder
	///
	/// E.G.
	/// <pre>
	/// `new Identifier("myMod", "workbench/sawmill")`</pre>
	public DefaultedBlockGeoModel(Identifier assetSubpath) {
		super(assetSubpath);
	}

	/// Returns the subtype string for this type of model
	///
	/// This allows for sorting of asset files into neat subdirectories for clean management.
	@Override
	protected String subtype() {
		return "block";
	}

	/// Changes the constructor-defined model path for this model to an alternate
	///
	/// This is useful if your animatable shares a model path with another animatable that differs in path to the texture and animations for this model
	@Override
	public DefaultedBlockGeoModel<T> withAltModel(Identifier altPath) {
		return (DefaultedBlockGeoModel<T>)super.withAltModel(altPath);
	}

	/// Changes the constructor-defined animations path for this model to an alternate
	///
	/// This is useful if your animatable shares an animations path with another animatable that differs in path to the model and texture for this model
	@Override
	public DefaultedBlockGeoModel<T> withAltAnimations(Identifier altPath) {
		return (DefaultedBlockGeoModel<T>)super.withAltAnimations(altPath);
	}

	/// Changes the constructor-defined texture path for this model to an alternate
	///
	/// This is useful if your animatable shares a texture path with another animatable that differs in path to the model and animations for this model
	@Override
	public DefaultedBlockGeoModel<T> withAltTexture(Identifier altPath) {
		return (DefaultedBlockGeoModel<T>)super.withAltTexture(altPath);
	}
}
