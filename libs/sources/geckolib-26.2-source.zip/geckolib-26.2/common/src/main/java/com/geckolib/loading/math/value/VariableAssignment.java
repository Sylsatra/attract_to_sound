package com.geckolib.loading.math.value;

import org.jspecify.annotations.Nullable;
import com.geckolib.animation.state.ControllerState;
import com.geckolib.loading.math.MathValue;

import java.util.Set;

/// [MathValue] value supplier
///
/// **Contract:**
///
/// Assigns a variable to the given value, then returns 0
public record VariableAssignment(Variable variable, MathValue value) implements MathValue {
    @Override
    public double get(@Nullable ControllerState controllerState) {
        this.variable.set(this.value.get(controllerState));

        return 0;
    }

    @Override
    public Set<Variable> getUsedVariables() {
        return this.value.getUsedVariables();
    }

    @Override
    public String toString() {
        return this.variable.name() + "=" + this.value;
    }
}
