package com.geckolib.animatable.stateless;

import net.minecraft.world.entity.Entity;
import com.geckolib.GeckoLibServices;
import com.geckolib.animatable.SingletonGeoAnimatable;
import com.geckolib.animation.RawAnimation;
import com.geckolib.cache.SyncedSingletonAnimatableCache;
import com.geckolib.network.packet.singleton.StatelessSingletonPlayAnimPacket;
import com.geckolib.network.packet.singleton.StatelessSingletonStopAnimPacket;

/// Extension of [StatelessAnimatable] for [SingletonGeoAnimatable] animatables.
///
/// Animatables **<u>MUST</u>** be registered with [SingletonGeoAnimatable#registerSyncedAnimatable] to use this interface
public non-sealed interface StatelessGeoSingletonAnimatable extends StatelessAnimatable, SingletonGeoAnimatable {
    /// Start or continue an animation, letting its pre-defined loop type determine whether it should loop or not
    default void playAnimation(String animation, Entity relatedEntity, long instanceId) {
        playAnimation(RawAnimation.begin().thenPlay(animation), relatedEntity, instanceId);
    }

    /// Start or continue an animation, forcing it to loop continuously until stopped
    default void playLoopingAnimation(String animation, Entity relatedEntity, long instanceId) {
        playAnimation(RawAnimation.begin().thenLoop(animation), relatedEntity, instanceId);
    }

    /// Start or continue an animation, then hold the pose at the end of the animation until otherwise stopped
    default void playAndHoldAnimation(String animation, Entity relatedEntity, long instanceId) {
        playAnimation(RawAnimation.begin().thenPlayAndHold(animation), relatedEntity, instanceId);
    }

    /// Stop an already-playing animation
    default void stopAnimation(RawAnimation animation, Entity relatedEntity, long instanceId) {
        stopAnimation(animation.getStageCount() == 1 ? animation.getAnimationStages().getFirst().animationName() : animation.toString(), relatedEntity, instanceId);
    }

    /// Start or continue a pre-defined animation
    default void playAnimation(RawAnimation animation, Entity relatedEntity, long instanceId) {
        if (relatedEntity.level().isClientSide()) {
            handleClientAnimationPlay(this, instanceId, animation);
        }
        else {
            GeckoLibServices.NETWORK.sendToAllPlayersTrackingEntity(new StatelessSingletonPlayAnimPacket(SyncedSingletonAnimatableCache.getOrCreateId(this), instanceId, animation), relatedEntity);
        }
    }

    /// Stop an already-playing animation
    default void stopAnimation(String animation, Entity relatedEntity, long instanceId) {
        if (relatedEntity.level().isClientSide()) {
            handleClientAnimationStop(this, instanceId, animation);
        }
        else {
            GeckoLibServices.NETWORK.sendToAllPlayersTrackingEntity(new StatelessSingletonStopAnimPacket(SyncedSingletonAnimatableCache.getOrCreateId(this), instanceId, animation), relatedEntity);
        }
    }

    // Unsupported method handlers below; do not use

    /// @deprecated Use [#playAnimation(String, Entity, long)] instead.
    @Deprecated
    default void playAnimation(String animation) {
        throw new IllegalStateException("Cannot use non-level method handlers on StatelessSingletonGeoAnimatable");
    }

    /// @deprecated Use [#playLoopingAnimation(String, Entity, long)] instead.
    @Deprecated
    default void playLoopingAnimation(String animation) {
        throw new IllegalStateException("Cannot use non-level method handlers on StatelessSingletonGeoAnimatable");
    }

    /// @deprecated Use [#playAndHoldAnimation(String, Entity, long)] instead.
    @Deprecated
    default void playAndHoldAnimation(String animation) {
        throw new IllegalStateException("Cannot use non-level method handlers on StatelessSingletonGeoAnimatable");
    }

    /// @deprecated Use [#stopAnimation(RawAnimation, Entity, long)] instead.
    @Deprecated
    default void stopAnimation(RawAnimation animation) {
        throw new IllegalStateException("Cannot use non-level method handlers on StatelessSingletonGeoAnimatable");
    }

    /// @deprecated Use [#playAnimation(RawAnimation, Entity, long)] instead.
    @Deprecated
    default void playAnimation(RawAnimation animation) {
        throw new IllegalStateException("Cannot use non-level method handlers on StatelessSingletonGeoAnimatable");
    }

    /// @deprecated Use [#stopAnimation(String, Entity, long)] instead.
    @Deprecated
    default void stopAnimation(String animation) {
        throw new IllegalStateException("Cannot use non-level method handlers on StatelessSingletonGeoAnimatable");
    }
}
