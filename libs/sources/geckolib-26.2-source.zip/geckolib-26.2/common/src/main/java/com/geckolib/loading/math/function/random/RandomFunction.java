package com.geckolib.loading.math.function.random;

import org.jspecify.annotations.Nullable;
import com.geckolib.animation.state.ControllerState;
import com.geckolib.loading.math.MathValue;
import com.geckolib.loading.math.function.MathFunction;

import java.util.Random;

/// [MathFunction] value supplier
///
/// **Contract:**
///
/// Returns a random value based on the input values:
///
///   - A single input generates a value between 0 and that input (exclusive)
///   - Two inputs generates a random value between the first (inclusive) and second input (exclusive)
///   - Three inputs generates a random value between the first (inclusive) and second input (exclusive), seeded by the third input
///
public final class RandomFunction extends MathFunction {
    private final MathValue valueA;
    private final @Nullable MathValue valueB;
    private final @Nullable MathValue seed;
    private final @Nullable Random random;

    public RandomFunction(MathValue... values) {
        super(values);

        this.valueA = values[0];
        this.valueB = values.length >= 2 ? values[1] : null;
        this.seed = values.length >= 3 ? values[2] : null;
        this.random = this.seed != null ? new Random() : null;
    }

    @Override
    public String getName() {
        return "math.random";
    }

    @Override
    public double compute(@Nullable ControllerState controllerState) {
        double result;
        double valueA = this.valueA.get(controllerState);

        if (this.random != null && this.seed != null) {
            this.random.setSeed((long)this.seed.get(controllerState));

            result = this.random.nextDouble();
        }
        else {
            result = Math.random();
        }

        if (this.valueB != null) {
            double valueB = this.valueB.get(controllerState);
            double min = Math.min(valueA, valueB);
            double max = Math.max(valueA, valueB);

            result = min + result * (max - min);
        }
        else {
            result = result * valueA;
        }

        return result;
    }

    @Override
    public boolean isMutable(MathValue... values) {
        if (values.length < 3)
            return true;

        return super.isMutable(values);
    }

    @Override
    public int getMinArgs() {
        return 1;
    }

    @Override
    public MathValue[] getArgs() {
        if (this.seed != null)
            return new MathValue[] {this.valueA, this.valueB, this.seed};

        if (this.valueB != null)
            return new MathValue[] {this.valueA, this.valueB};

        return new MathValue[] {this.valueA};
    }
}
