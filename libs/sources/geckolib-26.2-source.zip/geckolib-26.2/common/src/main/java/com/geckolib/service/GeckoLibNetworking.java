package com.geckolib.service;

import com.geckolib.GeckoLibServices;
import com.geckolib.animatable.GeoBlockEntity;
import com.geckolib.animatable.GeoEntity;
import com.geckolib.animatable.SingletonGeoAnimatable;
import com.geckolib.cache.SyncedSingletonAnimatableCache;
import com.geckolib.network.packet.MultiloaderPacket;
import com.geckolib.network.packet.blockentity.BlockEntityAnimTriggerPacket;
import com.geckolib.network.packet.blockentity.StatelessBlockEntityPlayAnimPacket;
import com.geckolib.network.packet.blockentity.StatelessBlockEntityStopAnimPacket;
import com.geckolib.network.packet.blockentity.StopTriggeredBlockEntityAnimPacket;
import com.geckolib.network.packet.entity.EntityAnimTriggerPacket;
import com.geckolib.network.packet.entity.StatelessEntityPlayAnimPacket;
import com.geckolib.network.packet.entity.StatelessEntityStopAnimPacket;
import com.geckolib.network.packet.entity.StopTriggeredEntityAnimPacket;
import com.geckolib.network.packet.singleton.SingletonAnimTriggerPacket;
import com.geckolib.network.packet.singleton.StatelessSingletonPlayAnimPacket;
import com.geckolib.network.packet.singleton.StatelessSingletonStopAnimPacket;
import com.geckolib.network.packet.singleton.StopTriggeredSingletonAnimPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;

import java.util.Optional;

/// Loader-agnostic service interface for GeckoLib's networking functionalities
public interface GeckoLibNetworking {
    static void init() {
        registerPacket(BlockEntityAnimTriggerPacket.TYPE, BlockEntityAnimTriggerPacket.CODEC, true);
        registerPacket(SingletonAnimTriggerPacket.TYPE, SingletonAnimTriggerPacket.CODEC, true);
        registerPacket(EntityAnimTriggerPacket.TYPE, EntityAnimTriggerPacket.CODEC, true);

        registerPacket(StopTriggeredBlockEntityAnimPacket.TYPE, StopTriggeredBlockEntityAnimPacket.CODEC, true);
        registerPacket(StopTriggeredEntityAnimPacket.TYPE, StopTriggeredEntityAnimPacket.CODEC, true);
        registerPacket(StopTriggeredSingletonAnimPacket.TYPE, StopTriggeredSingletonAnimPacket.CODEC, true);

        registerPacket(StatelessEntityPlayAnimPacket.TYPE, StatelessEntityPlayAnimPacket.CODEC, true);
        registerPacket(StatelessBlockEntityPlayAnimPacket.TYPE, StatelessBlockEntityPlayAnimPacket.CODEC, true);
        registerPacket(StatelessSingletonPlayAnimPacket.TYPE, StatelessSingletonPlayAnimPacket.CODEC, true);

        registerPacket(StatelessEntityStopAnimPacket.TYPE, StatelessEntityStopAnimPacket.CODEC, true);
        registerPacket(StatelessBlockEntityStopAnimPacket.TYPE, StatelessBlockEntityStopAnimPacket.CODEC, true);
        registerPacket(StatelessSingletonStopAnimPacket.TYPE, StatelessSingletonStopAnimPacket.CODEC, true);
    }

    /// Register a GeckoLib packet for use
    @ApiStatus.Internal
    private static <B extends FriendlyByteBuf, P extends MultiloaderPacket> void registerPacket(CustomPacketPayload.Type<P> payloadType, StreamCodec<B, P> codec, boolean isClientBound) {
        GeckoLibServices.NETWORK.registerPacketInternal(payloadType, codec, isClientBound);
    }

    /// Register a GeckoLib packet for use
    ///
    /// **<u>FOR GECKOLIB USE ONLY</u>**
    @ApiStatus.Internal
    <B extends FriendlyByteBuf, P extends MultiloaderPacket> void registerPacketInternal(CustomPacketPayload.Type<P> payloadType, StreamCodec<B, P> codec, boolean isClientBound);

    /// Send a packet to all players currently tracking a given entity
    ///
    /// Good as a shortcut for sending a packet to all players that may have an interest in a given entity or its dealings
    ///
    /// Will also send the packet to the entity itself if the entity is also a player
    void sendToAllPlayersTrackingEntity(MultiloaderPacket packet, Entity trackingEntity);

    /// Send a packet to all players tracking a given block position
    void sendToAllPlayersTrackingBlock(MultiloaderPacket packet, ServerLevel level, BlockPos pos);

    /// Send a packet to the given player
    void sendToPlayer(MultiloaderPacket packet, ServerPlayer player);

    /// [Trigger][GeoBlockEntity#triggerAnim(String, String)] an animation for the
    /// given [GeoBlockEntity][GeoBlockEntity]
    default void triggerBlockEntityAnim(BlockPos pos, ServerLevel level, @Nullable String controllerName, String animName) {
        sendToAllPlayersTrackingBlock(new BlockEntityAnimTriggerPacket(pos, Optional.ofNullable(controllerName), animName), level, pos);
    }

    /// [Trigger][GeoEntity#triggerAnim(String, String)] an animation for the given
    /// [GeoEntity][GeoEntity]
    default void triggerEntityAnim(Entity entity, boolean isReplacedEntity, @Nullable String controllerName, String animName) {
        sendToAllPlayersTrackingEntity(new EntityAnimTriggerPacket(entity.getId(), isReplacedEntity, Optional.ofNullable(controllerName), animName), entity);
    }

    /// [Trigger][SingletonGeoAnimatable#triggerAnim(Entity, long, String, String)]
    /// an animation for the given [SingletonGeoAnimatable][SingletonGeoAnimatable]
    default void triggerSingletonAnim(SingletonGeoAnimatable animatable, Entity entityToTrack, long instanceId, @Nullable String controllerName, String animName) {
        sendToAllPlayersTrackingEntity(new SingletonAnimTriggerPacket(SyncedSingletonAnimatableCache.getOrCreateId(animatable), instanceId, Optional.ofNullable(controllerName), animName), entityToTrack);
    }

    /// [Stop][GeoBlockEntity#stopTriggeredAnim(String, String)] a previously triggered
    /// animation for the given [GeoBlockEntity][GeoBlockEntity]
    default void stopTriggeredBlockEntityAnim(BlockPos pos, ServerLevel level, @Nullable String controllerName, @Nullable String animName) {
        sendToAllPlayersTrackingBlock(new StopTriggeredBlockEntityAnimPacket(pos, Optional.ofNullable(controllerName), Optional.ofNullable(animName)), level, pos);
    }

    /// [Stop][GeoEntity#stopTriggeredAnim(String, String)] a previously triggered
    /// animation for the given [GeoEntity][GeoEntity]
    default void stopTriggeredEntityAnim(Entity entity, boolean isReplacedEntity, @Nullable String controllerName, @Nullable String animName) {
        sendToAllPlayersTrackingEntity(new StopTriggeredEntityAnimPacket(entity.getId(), isReplacedEntity, Optional.ofNullable(controllerName), Optional.ofNullable(animName)), entity);
    }

    /// [Stop][SingletonGeoAnimatable#stopTriggeredAnim(Entity, long, String, String)]
    /// a previously triggered animation for the given [SingletonGeoAnimatable][SingletonGeoAnimatable]
    default void stopTriggeredSingletonAnim(SingletonGeoAnimatable animatable, Entity entityToTrack, long instanceId, @Nullable String controllerName, @Nullable String animName) {
        sendToAllPlayersTrackingEntity(new StopTriggeredSingletonAnimPacket(SyncedSingletonAnimatableCache.getOrCreateId(animatable), instanceId, Optional.ofNullable(controllerName), Optional.ofNullable(animName)), entityToTrack);
    }
}
