package com.geckolib.loading.math.function.random;

import org.jspecify.annotations.Nullable;
import com.geckolib.animation.state.ControllerState;
import com.geckolib.loading.math.MathValue;
import com.geckolib.loading.math.function.MathFunction;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/// [MathFunction] value supplier
///
/// **Contract:**
///
/// Returns a random integer value based on the input values:
///
///   - A single input generates a value between 0 and that input (exclusive)
///   - Two inputs generates a random value between the first (inclusive) and second input (inclusive)
///   - Three inputs generates a random value between the first (inclusive) and second input (inclusive), seeded by the third input
///
public final class RandomIntegerFunction extends MathFunction {
    private final MathValue valueA;
    private final @Nullable MathValue valueB;
    private final @Nullable MathValue seed;
    private final @Nullable Random random;

    public RandomIntegerFunction(MathValue... values) {
        super(values);

        this.valueA = values[0];
        this.valueB = values.length >= 2 ? values[1] : null;
        this.seed = values.length >= 3 ? values[2] : null;
        this.random = this.seed != null ? new Random() : null;
    }

    @Override
    public String getName() {
        return "math.random_integer";
    }

    @Override
    public double compute(@Nullable ControllerState controllerState) {
        int result;
        int valueA = (int)Math.round(this.valueA.get(controllerState));
        Random random;

        if (this.random != null && this.seed != null) {
            this.random.setSeed((long)this.seed.get(controllerState));
            random = this.random;
        }
        else {
            random = ThreadLocalRandom.current();
        }

        if (this.valueB != null) {
            int valueB = (int)Math.round(this.valueB.get(controllerState));
            int min = Math.min(valueA, valueB);
            int max = Math.max(valueA, valueB);

            result = min + random.nextInt(max + 1 - min);
        }
        else {
            int max = Math.max(valueA + 1, 0);
            int min = Math.min(valueA + 1, 0);
            result = random.nextInt(min, max);
        }

        return result;
    }

    @Override
    public boolean isMutable(MathValue... values) {
        if (values.length < 3)
            return true;

        return super.isMutable(values);
    }

    @Override
    public int getMinArgs() {
        return 1;
    }

    @Override
    public MathValue[] getArgs() {
        if (this.seed != null)
            return new MathValue[] {this.valueA, this.valueB, this.seed};

        if (this.valueB != null)
            return new MathValue[] {this.valueA, this.valueB};

        return new MathValue[] {this.valueA};
    }
}
