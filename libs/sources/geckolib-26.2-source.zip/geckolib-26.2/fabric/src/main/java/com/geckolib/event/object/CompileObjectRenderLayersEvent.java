package com.geckolib.event.object;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import com.geckolib.animatable.GeoAnimatable;
import com.geckolib.event.GeoRenderEvent;
import com.geckolib.renderer.GeoObjectRenderer;
import com.geckolib.renderer.base.GeoRenderState;

/// One-time event for a [GeoObjectRenderer] called on first initialisation
///
/// Use this event to add render layers to the renderer as needed
///
/// **<u>NOTE:</u>** Some methods on this event are not overridden in this class. Check [GeoRenderEvent]
///
/// @param <T> Object animatable class type
/// @param <E> Associated object class type, or [Void] if none
/// @param <R> RenderState class type
/// @see GeoRenderEvent
/// @see CompileRenderLayers
public class CompileObjectRenderLayersEvent<T extends GeoAnimatable, E, R extends GeoRenderState> implements GeoRenderEvent.Object.CompileRenderLayers<T, E, R> {
    public static final Event<Listener> EVENT = EventFactory.createArrayBacked(Listener.class, post -> {}, listeners -> event -> {
        for (Listener<?, ?, ?> listener : listeners) {
            listener.handle(event);
        }
    });
    private final GeoObjectRenderer<T, E, R> renderer;

    public CompileObjectRenderLayersEvent(GeoObjectRenderer<T, E, R> renderer) {
        this.renderer = renderer;
    }

    @Override
    public GeoObjectRenderer<T, E, R> getRenderer() {
        return this.renderer;
    }

    /// Event listener interface for the [Object.CompileRenderLayers] GeoRenderEvent
    ///
    /// @param <T> Object animatable class type
    /// @param <E> Associated object class type, or [Void] if none
    /// @param <R> RenderState class type
    @FunctionalInterface
    public interface Listener<T extends GeoAnimatable, E, R extends GeoRenderState> {
        void handle(CompileObjectRenderLayersEvent<T, E, R> event);
    }
}
