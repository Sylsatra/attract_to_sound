package com.geckolib.event.block;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.world.level.block.entity.BlockEntity;
import com.geckolib.animatable.GeoAnimatable;
import com.geckolib.event.GeoRenderEvent;
import com.geckolib.renderer.GeoArmorRenderer;
import com.geckolib.renderer.GeoBlockRenderer;
import com.geckolib.renderer.base.GeoRenderState;

/// One-time event for a [GeoArmorRenderer] called on first initialisation
///
/// Use this event to add render layers to the renderer as needed
///
/// **<u>NOTE:</u>** Some methods on this event are not overridden in this class. Check [GeoRenderEvent]
///
/// @param <T> BlockEntity animatable class type
/// @param <R> RenderState class type
/// @see GeoRenderEvent
/// @see Armor.CompileRenderLayers
public class CompileBlockRenderLayersEvent<T extends BlockEntity & GeoAnimatable, R extends BlockEntityRenderState> implements GeoRenderEvent.Block.CompileRenderLayers<T, R> {
    public static final Event<Listener> EVENT = EventFactory.createArrayBacked(Listener.class, post -> {}, listeners -> event -> {
        for (Listener<?, ?> listener : listeners) {
            listener.handle(event);
        }
    });
    private final GeoBlockRenderer<T, R> renderer;

    public CompileBlockRenderLayersEvent(GeoBlockRenderer<T, R> renderer) {
        this.renderer = renderer;
    }

    @Override
    public GeoBlockRenderer<T, R> getRenderer() {
        return this.renderer;
    }

    /// Event listener interface for the [CompileBlockRenderLayersEvent] GeoRenderEvent
    ///
    /// @param <T> BlockEntity animatable class type
    /// @param <R> RenderState class type
    @FunctionalInterface
    public interface Listener<T extends BlockEntity & GeoAnimatable, R extends BlockEntityRenderState> {
        void handle(CompileBlockRenderLayersEvent<T, R> event);
    }
}
