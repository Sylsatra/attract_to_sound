package com.geckolib.event.replacedentity;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.world.entity.Entity;
import com.geckolib.animatable.GeoAnimatable;
import com.geckolib.event.GeoRenderEvent;
import com.geckolib.renderer.GeoReplacedEntityRenderer;
import com.geckolib.renderer.base.GeoRenderState;

/// One-time event for a [GeoReplacedEntityRenderer] called on first initialisation
///
/// Use this event to add render layers to the renderer as needed
///
/// **<u>NOTE:</u>** Some methods on this event are not overridden in this class. Check [GeoRenderEvent]
///
/// @param <T> Entity animatable class type. This is the animatable being rendered
/// @param <E> Entity class type. This is the entity being replaced
/// @param <R> RenderState class type. Typically, this would match the RenderState class the replaced entity uses in their renderer
/// @see GeoRenderEvent
/// @see CompileRenderLayers
public class CompileReplacedEntityRenderLayersEvent<T extends GeoAnimatable, E extends Entity, R extends EntityRenderState> implements GeoRenderEvent.ReplacedEntity.CompileRenderLayers<T, E, R> {
    public static final Event<Listener> EVENT = EventFactory.createArrayBacked(Listener.class, post -> {}, listeners -> event -> {
        for (Listener<?, ?, ?> listener : listeners) {
            listener.handle(event);
        }
    });
    private final GeoReplacedEntityRenderer<T, E, R> renderer;

    public CompileReplacedEntityRenderLayersEvent(GeoReplacedEntityRenderer<T, E, R> renderer) {
        this.renderer = renderer;
    }

    @Override
    public GeoReplacedEntityRenderer<T, E, R> getRenderer() {
        return this.renderer;
    }

    /// Event listener interface for the [ReplacedEntity.CompileRenderLayers] GeoRenderEvent
    ///
    /// @param <T> Entity animatable class type. This is the animatable being rendered
    /// @param <E> Entity class type. This is the entity being replaced
    /// @param <R> RenderState class type. Typically, this would match the RenderState class the replaced entity uses in their renderer
    @FunctionalInterface
    public interface Listener<T extends GeoAnimatable, E extends net.minecraft.world.entity.Entity, R extends EntityRenderState> {
        void handle(CompileReplacedEntityRenderLayersEvent<T, E, R> event);
    }
}
