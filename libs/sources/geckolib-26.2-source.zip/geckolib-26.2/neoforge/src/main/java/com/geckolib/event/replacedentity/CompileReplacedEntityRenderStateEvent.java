package com.geckolib.event.replacedentity;

import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.world.entity.Entity;
import net.neoforged.bus.api.Event;
import org.jetbrains.annotations.ApiStatus;
import com.geckolib.animatable.GeoAnimatable;
import com.geckolib.event.GeoRenderEvent;
import com.geckolib.renderer.GeoEntityRenderer;
import com.geckolib.renderer.GeoReplacedEntityRenderer;
import com.geckolib.renderer.base.GeoRenderState;

/// Pre-render event for entities being rendered by [GeoEntityRenderer]
///
/// This event is called in preparation for rendering, when the renderer is gathering data to pass through
///
/// Use this event to add data that you may need in a later [ReplacedEntity] event, or to override/replace data used in rendering
///
/// **<u>NOTE:</u>** Some methods on this event are not overridden in this class. Check [GeoRenderEvent]
///
/// @see GeoRenderEvent
/// @see CompileRenderState
public class CompileReplacedEntityRenderStateEvent<T extends GeoAnimatable, E extends Entity, R extends EntityRenderState> extends Event implements GeoRenderEvent.ReplacedEntity.CompileRenderState<T, E, R> {
    private final GeoReplacedEntityRenderer<T, E, R> renderer;
    private final R renderState;
    private final T animatable;
    private final E entity;

    public CompileReplacedEntityRenderStateEvent(GeoReplacedEntityRenderer<T, E, R> renderer, R renderState, T animatable, E entity) {
        this.renderer = renderer;
        this.renderState = renderState;
        this.animatable = animatable;
        this.entity = entity;
    }

    @Override
    public GeoReplacedEntityRenderer<T, E, R> getRenderer() {
        return this.renderer;
    }

    @Override
    public net.minecraft.world.entity.Entity getReplacedEntity() {
        return this.entity;
    }

    @Override
    public T getAnimatable() {
        return this.animatable;
    }

    @ApiStatus.Internal
    @Override
    public R getRenderState() {
        return this.renderState;
    }
}
