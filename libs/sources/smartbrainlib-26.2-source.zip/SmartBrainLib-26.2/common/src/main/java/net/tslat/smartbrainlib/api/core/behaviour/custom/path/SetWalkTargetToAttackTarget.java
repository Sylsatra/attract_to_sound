package net.tslat.smartbrainlib.api.core.behaviour.custom.path;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.behavior.BehaviorUtils;
import net.minecraft.world.entity.ai.behavior.EntityTracker;
import net.minecraft.world.entity.ai.behavior.declarative.MemoryCondition;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.MemoryStatus;
import net.minecraft.world.entity.ai.memory.WalkTarget;
import net.tslat.smartbrainlib.api.core.behaviour.base.ExtendedBehaviour;
import net.tslat.smartbrainlib.library.interfaces.ToFloatBiFunction;
import net.tslat.smartbrainlib.library.object.MemoryTest;
import net.tslat.smartbrainlib.util.BrainUtil;
import org.apache.commons.lang3.function.ToBooleanBiFunction;
import org.jetbrains.annotations.ApiStatus;

import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.ToIntBiFunction;
import java.util.function.ToIntFunction;

/// Set the [walk target][MemoryModuleType#WALK_TARGET] of the entity to its current [attack target][MemoryModuleType#ATTACK_TARGET]
///
/// @param <BO> The brain owner entity
public class SetWalkTargetToAttackTarget<BO extends PathfinderMob> extends ExtendedBehaviour<BO> {
	protected static final MemoryTest MEMORY_REQUIREMENTS = MemoryTest.builder(3).hasMemory(MemoryModuleType.ATTACK_TARGET).usesMemories(MemoryModuleType.WALK_TARGET, MemoryModuleType.LOOK_TARGET);
	
	protected ToFloatBiFunction<BO, LivingEntity> speedModifier = (_, _) -> 1f;
	protected ToIntBiFunction<BO, LivingEntity> closeEnoughDist = (_, _) -> 0;
	protected ToBooleanBiFunction<BO, LivingEntity> targetEyePosition = (_, _) -> false;
	
	/// Set the movement speed modifier for the path when chosen
	@ApiStatus.NonExtendable
	public SetWalkTargetToAttackTarget<BO> speedModifier(float modifier) {
		return speedModifier((_, _) -> modifier);
	}
	
	/// Set the function to determine the movement speed modifier for the path when chosen
	@ApiStatus.NonExtendable
	public SetWalkTargetToAttackTarget<BO> speedModifier(ToFloatBiFunction<BO, LivingEntity> function) {
		this.speedModifier = function;
		
		return this;
	}
	
	/// Set the distance (in blocks) that the entity should be considered 'close enough' to the target position to have arrived
	@ApiStatus.NonExtendable
	public SetWalkTargetToAttackTarget<BO> closeEnoughDist(int distance) {
		return closeEnoughDist((_, _) -> distance);
	}
	
	/// Set the function to determine the distance (in blocks) that the entity should be considered 'close enough' to the target position to have arrived
	@ApiStatus.NonExtendable
	public SetWalkTargetToAttackTarget<BO> closeEnoughDist(ToIntBiFunction<BO, LivingEntity> function) {
		this.closeEnoughDist = function;
		
		return this;
	}

    /// Sets the walk target location to be the target's eye height, rather than their feet
    ///
    /// This is useful for flying entities as they will otherwise just keep hitting the ground
    @ApiStatus.NonExtendable
    public SetWalkTargetToAttackTarget<BO> targetEyePosition() {
        return targetEyePosition((_, _) -> true);
    }

    /// Set a function to determine whether to set the walk target location to be the target's eye height, rather than their feet
    ///
    /// This is useful for flying entities as they will otherwise just keep hitting the ground
    @ApiStatus.NonExtendable
    public SetWalkTargetToAttackTarget<BO> targetEyePosition(ToBooleanBiFunction<BO, LivingEntity> function) {
        this.targetEyePosition = function;

        return this;
    }
	
	//<editor-fold defaultstate="collapsed" desc="<Polymorphic Overloads>">
	/// Set a callback for when the behaviour successfully begins
	///
	/// This is called immediately prior to [ExtendedBehaviour#start(LivingEntity)]
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> whenStarting(Consumer<BO> callback) {
		return (SetWalkTargetToAttackTarget<BO>)super.whenStarting(callback);
	}
	
	/// Set a callback for when the behaviour stops
	///
	/// This is called immediately prior to [ExtendedBehaviour#stop(LivingEntity)]
	///
	/// Note that the behaviour stopping does not necessarily mean it was successful
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> whenStopping(Consumer<BO> callback) {
		return (SetWalkTargetToAttackTarget<BO>)super.whenStopping(callback);
	}
	
	/// Set the number of ticks the behaviour should try to run for, once started
	///
	/// The behaviour may still be stopped before this time runs out through other conditions or manual stops
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> runFor(int ticks) {
		return (SetWalkTargetToAttackTarget<BO>)super.runFor(ticks);
	}
	
	/// Set the range of ticks the behaviour should try to run for, once started<br/>
	/// The actual duration will be a random number selected between the min and max values (inclusive) each time the behaviour is run
	///
	/// The behaviour may still be stopped before this time runs out through other conditions or manual stops
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> runFor(int minTicks, int maxTicks) {
		return (SetWalkTargetToAttackTarget<BO>)super.runFor(minTicks, maxTicks);
	}
	
	/// Set a function to determine the number of ticks the behaviour should try to run for, once started
	///
	/// The behaviour may still be stopped before this time runs out through other conditions or manual stops
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> runFor(ToIntFunction<BO> timeProvider) {
		return (SetWalkTargetToAttackTarget<BO>)super.runFor(timeProvider);
	}
	
	/// Disable the tick-based timeout for this behaviour and instead rely exclusively on other conditions
	/// such as [#getMemoryRequirements()] failing or [#stopIf(Predicate)]
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> noTimeout() {
		return (SetWalkTargetToAttackTarget<BO>)super.noTimeout();
	}
	
	/// Set the number of ticks that this behaviour should be prevented from starting again after it has finished
	///
	/// This is the length of time between when this behaviour stops and it can start again
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> cooldownFor(int ticks) {
		return (SetWalkTargetToAttackTarget<BO>)super.cooldownFor(ticks);
	}
	
	/// Set the range of ticks that this behaviour should be prevented from starting again after it has finished<br/>
	/// The actual duration will be a random number selected between the min and max values (inclusive) each time the behaviour is stopped
	///
	/// This is the length of time between when this behaviour stops and it can start again
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> cooldownFor(int minTicks, int maxTicks) {
		return (SetWalkTargetToAttackTarget<BO>)super.cooldownFor(minTicks, maxTicks);
	}
	
	/// Set a function to determine the number of ticks that this behaviour should be prevented from starting again after it has finished
	///
	/// This is the length of time between when this behaviour stops and it can start again
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> cooldownFor(ToIntFunction<BO> timeProvider) {
		return (SetWalkTargetToAttackTarget<BO>)super.cooldownFor(timeProvider);
	}
	
	/// Set an additional condition for the behaviour to be able to start
	///
	/// Prevents this behaviour starting unless this predicate returns true.
	///
	/// @param predicate The condition for starting
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> startCondition(Predicate<BO> predicate) {
		return (SetWalkTargetToAttackTarget<BO>)super.startCondition(predicate);
	}
	
	/// Set a condition under which the behaviour should automatically stop<br/>
	/// Has no effect on one-shot behaviours that don't tick or have a runtime
	///
	/// Stops the behaviour immediately if the predicate returns true, ready to run again
	@ApiStatus.NonExtendable
	@Override
	public SetWalkTargetToAttackTarget<BO> stopIf(Predicate<BO> predicate) {
		return (SetWalkTargetToAttackTarget<BO>)super.stopIf(predicate);
	}
	//</editor-fold>
	//<editor-fold defaultstate="collapsed" desc="<Internal Handling>">
	/// The set of memory requirements this task has before starting<br/>
	/// This outlines the approximate state the brain should be in to allow this behaviour to run
	///
	/// Ideally, this would be a statically cached set
	///
	/// @return The [Set] of [Memories][MemoryModuleType] and their associated required [status][MemoryStatus]
	/// @see MemoryTest
	@Override
    public Set<MemoryCondition<?, ?>> getMemoryRequirements() {
		return MEMORY_REQUIREMENTS;
	}
	
	/// Run the core functionality this behaviour has when starting<br/>
	/// This method is called once per behaviour run
	///
	/// By this stage any memory requirements set in [#getMemoryRequirements()] are true, so any memories paired with [MemoryStatus#VALUE_PRESENT] are safe to retrieve
	///
	/// If you are not making a custom behaviour and are instead just using an existing behaviour; you would use [#whenStarting(Consumer)] instead of overriding this method
	@Override
	protected void start(BO entity) {
		final Brain<?> brain = entity.getBrain();
		final LivingEntity target = BrainUtil.getTargetOfEntity(entity);

		if (target == null)
			return;
		
		if (entity.getSensing().hasLineOfSight(target) && BehaviorUtils.isWithinAttackRange(entity, target, 1)) {
			BrainUtil.clearMemory(brain, MemoryModuleType.WALK_TARGET);
		}
		else {
			BrainUtil.setMemory(brain, MemoryModuleType.LOOK_TARGET, new EntityTracker(target, true));
			BrainUtil.setMemory(brain, MemoryModuleType.WALK_TARGET, new WalkTarget(new EntityTracker(target, this.targetEyePosition.applyAsBoolean(entity, target)),
			                                                                        this.speedModifier.applyAsFloat(entity, target), this.closeEnoughDist.applyAsInt(entity, target)));
		}
	}
	//</editor-fold>
}
