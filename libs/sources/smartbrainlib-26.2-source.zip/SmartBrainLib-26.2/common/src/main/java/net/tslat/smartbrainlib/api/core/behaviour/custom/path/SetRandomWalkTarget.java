package net.tslat.smartbrainlib.api.core.behaviour.custom.path;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.ai.util.LandRandomPos;
import net.minecraft.world.phys.Vec3;
import net.tslat.smartbrainlib.api.core.behaviour.base.ExtendedBehaviour;
import net.tslat.smartbrainlib.library.interfaces.ToFloatBiFunction;
import net.tslat.smartbrainlib.library.object.SquareRadius;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;

import java.util.function.*;

/// Set a random position to walk to
///
/// @param <BO> The brain owner entity
public class SetRandomWalkTarget<BO extends PathfinderMob> extends SetRandomMoveTarget<BO> {
	protected Predicate<BO> avoidWaterPredicate = _ -> true;

	/// Sets the behaviour to allow finding of positions that might be in water
	///
	/// Useful for hybrid or water-based entities
	@ApiStatus.NonExtendable
	public SetRandomWalkTarget<BO> dontAvoidWater() {
		return avoidWaterIf(_ -> false);
	}

	/// Set the predicate to determine if the entity should avoid water walk target positions
	@ApiStatus.NonExtendable
	public SetRandomWalkTarget<BO> avoidWaterIf(Predicate<BO> predicate) {
		this.avoidWaterPredicate = predicate;

		return this;
	}
	
	//<editor-fold defaultstate="collapsed" desc="<Polymorphic Overloads>">
	/// Set the radius (in blocks) to look for flight positions
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> setRadius(double radius) {
		return (SetRandomWalkTarget<BO>)super.setRadius(radius);
	}
	
	/// Set the radius (in blocks) to look for flight positions
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> setRadius(double xz, double y) {
		return (SetRandomWalkTarget<BO>)super.setRadius(xz, y);
	}
	
	/// Set the function to determine the radius (in blocks) to look for flight positions
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> setRadius(Function<BO, SquareRadius> function) {
		return (SetRandomWalkTarget<BO>)super.setRadius(function);
	}
	
	/// Set the movement speed modifier for the path when chosen
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> speedModifier(float modifier) {
		return (SetRandomWalkTarget<BO>)super.speedModifier(modifier);
	}
	
	/// Set the function to determine the movement speed modifier for the path when chosen
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> speedModifier(ToFloatBiFunction<BO, Vec3> function) {
		return (SetRandomWalkTarget<BO>)super.speedModifier(function);
	}
	
	/// Sets a predicate to check whether a target movement position is valid or not
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> isValidPositionIf(BiPredicate<BO, Vec3> predicate) {
		return (SetRandomWalkTarget<BO>)super.isValidPositionIf(predicate);
	}
	
	/// Set the distance (in blocks) that the entity should be considered 'close enough' to the target position to have arrived
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> closeEnoughDist(int distance) {
		return (SetRandomWalkTarget<BO>)super.closeEnoughDist(distance);
	}
	
	/// Set the function to determine the distance (in blocks) that the entity should be considered 'close enough' to the target position to have arrived
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> closeEnoughDist(ToIntBiFunction<BO, Vec3> function) {
		return (SetRandomWalkTarget<BO>)super.closeEnoughDist(function);
	}
	
	/// Set a callback for when the behaviour successfully begins
	///
	/// This is called immediately prior to [ExtendedBehaviour#start(LivingEntity)]
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> whenStarting(Consumer<BO> callback) {
		return (SetRandomWalkTarget<BO>)super.whenStarting(callback);
	}
	
	/// Set a callback for when the behaviour stops
	///
	/// This is called immediately prior to [#stop(LivingEntity)]
	///
	/// Note that the behaviour stopping does not necessarily mean it was successful
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> whenStopping(Consumer<BO> callback) {
		return (SetRandomWalkTarget<BO>)super.whenStopping(callback);
	}
	
	/// Set the number of ticks the behaviour should try to run for, once started
	///
	/// The behaviour may still be stopped before this time runs out through other conditions or manual stops
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> runFor(int ticks) {
		return (SetRandomWalkTarget<BO>)super.runFor(ticks);
	}
	
	/// Set the range of ticks the behaviour should try to run for, once started<br/>
	/// The actual duration will be a random number selected between the min and max values (inclusive) each time the behaviour is run
	/// 
	/// The behaviour may still be stopped before this time runs out through other conditions or manual stops
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> runFor(int minTicks, int maxTicks) {
		return (SetRandomWalkTarget<BO>)super.runFor(minTicks, maxTicks);
	}
	
	/// Set a function to determine the number of ticks the behaviour should try to run for, once started
	///
	/// The behaviour may still be stopped before this time runs out through other conditions or manual stops
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> runFor(ToIntFunction<BO> timeProvider) {
		return (SetRandomWalkTarget<BO>)super.runFor(timeProvider);
	}
	
	/// Disable the tick-based timeout for this behaviour and instead rely exclusively on other conditions
	/// such as [#getMemoryRequirements()] failing or [#stopIf(Predicate)]
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> noTimeout() {
		return (SetRandomWalkTarget<BO>)super.noTimeout();
	}
	
	/// Set the number of ticks that this behaviour should be prevented from starting again after it has finished
	///
	/// This is the length of time between when this behaviour stops and it can start again
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> cooldownFor(int ticks) {
		return (SetRandomWalkTarget<BO>)super.cooldownFor(ticks);
	}
	
	/// Set the range of ticks that this behaviour should be prevented from starting again after it has finished<br/>
	/// The actual duration will be a random number selected between the min and max values (inclusive) each time the behaviour is stopped
	///
	/// This is the length of time between when this behaviour stops and it can start again
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> cooldownFor(int minTicks, int maxTicks) {
		return (SetRandomWalkTarget<BO>)super.cooldownFor(minTicks, maxTicks);
	}
	
	/// Set a function to determine the number of ticks that this behaviour should be prevented from starting again after it has finished
	///
	/// This is the length of time between when this behaviour stops and it can start again
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> cooldownFor(ToIntFunction<BO> timeProvider) {
		return (SetRandomWalkTarget<BO>)super.cooldownFor(timeProvider);
	}
	
	/// Set an additional condition for the behaviour to be able to start
	///
	/// Prevents this behaviour starting unless this predicate returns true.
	///
	/// @param predicate The condition for starting
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> startCondition(Predicate<BO> predicate) {
		return (SetRandomWalkTarget<BO>)super.startCondition(predicate);
	}
	
	/// Set a condition under which the behaviour should automatically stop<br/>
	/// Has no effect on one-shot behaviours that don't tick or have a runtime
	/// 
	/// Stops the behaviour immediately if the predicate returns true, ready to run again
	@ApiStatus.NonExtendable
	@Override
	public SetRandomWalkTarget<BO> stopIf(Predicate<BO> predicate) {
		return (SetRandomWalkTarget<BO>)super.stopIf(predicate);
	}
	//</editor-fold>
	//<editor-fold defaultstate="collapsed" desc="<Internal Handling>">
	/// Get a new nearby position to attempt to move to
	///
	/// This position does not need to be predicated with the [#validPositionPredicate]
	@Override
	protected @Nullable Vec3 getTargetPos(BO entity) {
		final SquareRadius radius = this.radius.apply(entity);
		
		if (this.avoidWaterPredicate.test(entity))
			return LandRandomPos.getPos(entity, Mth.ceil(radius.xzRadius()), Mth.ceil(radius.yRadius()));
		
		return DefaultRandomPos.getPos(entity, Mth.ceil(radius.xzRadius()), Mth.ceil(radius.yRadius()));
	}
	//</editor-fold>
}