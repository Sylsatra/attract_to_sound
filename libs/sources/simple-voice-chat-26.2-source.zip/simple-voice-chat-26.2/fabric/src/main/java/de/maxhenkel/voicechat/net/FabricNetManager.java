package de.maxhenkel.voicechat.net;

import de.maxhenkel.voicechat.Voicechat;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashSet;
import java.util.Set;

public class FabricNetManager extends NetManager {

    private final Set<Identifier> packets;

    public FabricNetManager() {
        packets = new HashSet<>();
    }

    public Set<Identifier> getPackets() {
        return packets;
    }

    @Override
    public <T extends Packet<T>> Channel<T> registerReceiver(Class<T> packetType, boolean toClient, boolean toServer) {
        ClientServerChannel<T> c = new ClientServerChannel<>();
        try {
            T dummyPacket = packetType.getDeclaredConstructor().newInstance();
            CustomPacketPayload.Type<T> type = dummyPacket.type();
            packets.add(type.id());
            StreamCodec<RegistryFriendlyByteBuf, T> codec = new StreamCodec<>() {

                @Override
                public void encode(RegistryFriendlyByteBuf buf, T packet) {
                    packet.toBytes(buf);
                }

                @Override
                public T decode(RegistryFriendlyByteBuf buf) {
                    try {
                        T packet = packetType.getDeclaredConstructor().newInstance();
                        packet.fromBytes(buf);
                        return packet;
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            };
            if (toServer) {
                PayloadTypeRegistry.serverboundPlay().register(type, codec);
                ServerPlayNetworking.registerGlobalReceiver(type, (payload, context) -> {
                    try {
                        if (!Voicechat.SERVER.isCompatible(context.player()) && !packetType.equals(RequestSecretPacket.class)) {
                            return;
                        }
                        c.onServerPacket(context.player(), payload);
                    } catch (Exception e) {
                        Voicechat.LOGGER.error("Failed to process packet", e);
                    }
                });
            }
            if (toClient) {
                PayloadTypeRegistry.clientboundPlay().register(type, codec);
                if (FabricLoader.getInstance().getEnvironmentType().equals(EnvType.CLIENT)) {
                    ClientPlayNetworking.registerGlobalReceiver(type, (payload, context) -> {
                        try {
                            Minecraft.getInstance().execute(() -> c.onClientPacket(context.player(), payload));
                        } catch (Exception e) {
                            Voicechat.LOGGER.error("Failed to register packet receiver", e);
                        }
                    });
                }
            }
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
        return c;
    }

    @Override
    protected void sendToServerInternal(Packet<?> packet) {
        ClientPlayNetworking.send(packet);
    }

    @Override
    public void sendToClient(Packet<?> packet, ServerPlayer player) {
        ServerPlayNetworking.send(player, packet);
    }

}
