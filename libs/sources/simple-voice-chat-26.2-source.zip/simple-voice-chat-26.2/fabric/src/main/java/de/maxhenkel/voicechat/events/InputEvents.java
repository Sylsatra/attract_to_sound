package de.maxhenkel.voicechat.events;

import de.maxhenkel.voicechat.intercompatibility.ClientCompatibilityManager;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;

public class InputEvents {

    public static final Event<ClientCompatibilityManager.KeyboardEvent> KEYBOARD_KEY = EventFactory.createArrayBacked(ClientCompatibilityManager.KeyboardEvent.class, (listeners) -> (keyEvent) -> {
        for (ClientCompatibilityManager.KeyboardEvent event : listeners) {
            event.onKeyboardEvent(keyEvent);
        }
    });

    public static final Event<ClientCompatibilityManager.MouseEvent> MOUSE_KEY = EventFactory.createArrayBacked(ClientCompatibilityManager.MouseEvent.class, (listeners) -> (mouseButtonInfo, action) -> {
        for (ClientCompatibilityManager.MouseEvent event : listeners) {
            event.onMouseEvent(mouseButtonInfo, action);
        }
    });

    public static final Event<Runnable> HANDLE_KEYBINDS = EventFactory.createArrayBacked(Runnable.class, (listeners) -> () -> {
        for (Runnable event : listeners) {
            event.run();
        }
    });

}
