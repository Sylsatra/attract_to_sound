/*
 * Cardinal-Components-API
 * Copyright (C) 2019-2026 Ladysnake
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
 * OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.ladysnake.cca.test.block;

import net.minecraft.core.Direction;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.ladysnake.cca.api.v3.component.ComponentKey;
import org.ladysnake.cca.api.v3.component.ComponentRegistryV3;
import org.ladysnake.cca.api.v3.component.sync.AutoSyncedComponent;
import org.ladysnake.cca.test.base.SyncedVita;
import org.ladysnake.cca.test.base.Vita;

import java.util.EnumMap;
import java.util.Map;

public class VitaCompound implements AutoSyncedComponent {
    public static final ComponentKey<VitaCompound> KEY = ComponentRegistryV3.INSTANCE.getOrCreate(Identifier.fromNamespaceAndPath(CcaBlockTestMod.MOD_ID, "vita_compound"), VitaCompound.class);

    private final Map<Direction, SyncedVita> storage = new EnumMap<>(Direction.class);

    public VitaCompound(BlockEntity owner) {
        for (Direction side : Direction.values()) {
            storage.put(side, new SyncedVita(owner));
        }
    }

    @Override
    public void readData(ValueInput valueInput) {
        for (Map.Entry<Direction, SyncedVita> entry : this.storage.entrySet()) {
            valueInput.child(entry.getKey().name()).ifPresent(t -> entry.getValue().readData(t));
        }
    }

    @Override
    public void writeData(ValueOutput writeView) {
        storage.forEach((side, vita) -> vita.writeData(writeView.child(side.name())));
    }

    @Override
    public boolean shouldSyncWith(ServerPlayer player) {
        for (SyncedVita value : this.storage.values()) {
            if (value.shouldSyncWith(player)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void writeSyncPacket(RegistryFriendlyByteBuf buf, ServerPlayer recipient) {
        for (SyncedVita value : this.storage.values()) {
            if (value.shouldSyncWith(recipient)) {
                value.writeSyncPacket(buf, recipient);
            }
        }
    }

    @Override
    public void applySyncPacket(RegistryFriendlyByteBuf buf) {
        for (SyncedVita value : this.storage.values()) {
            value.applySyncPacket(buf);
        }
    }

    public Vita get(Direction side) {
        return storage.get(side);
    }
}
