/*
 * Cardinal-Components-API
 * Copyright (C) 2019-2026 Ladysnake
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
 * OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.ladysnake.cca.test.base;

import net.minecraft.resources.Identifier;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.ladysnake.cca.api.v3.component.ComponentKey;
import org.ladysnake.cca.api.v3.component.ComponentRegistry;
import org.ladysnake.cca.api.v3.component.tick.ClientTickingComponent;
import org.ladysnake.cca.api.v3.component.tick.ServerTickingComponent;

public class TickingTestComponent implements ServerTickingComponent, ClientTickingComponent {
    public static final ComponentKey<TickingTestComponent> KEY = ComponentRegistry.getOrCreate(Identifier.fromNamespaceAndPath("cca-base-test", "ticking"), TickingTestComponent.class);

    private int clientTicks;
    private int serverTicks;

    @Override
    public void readData(ValueInput readView) {
        this.clientTicks = readView.getIntOr("clientTicks", 0);
        this.serverTicks = readView.getIntOr("serverTicks", 0);
    }

    @Override
    public void writeData(ValueOutput writeView) {
        writeView.putInt("clientTicks", this.clientTicks);
        writeView.putInt("serverTicks", this.serverTicks);
    }

    @Override
    public void clientTick() {
        this.clientTicks++;
    }

    @Override
    public void serverTick() {
        this.serverTicks++;
    }

    public int clientTicks() {
        return clientTicks;
    }

    public int serverTicks() {
        return serverTicks;
    }
}
