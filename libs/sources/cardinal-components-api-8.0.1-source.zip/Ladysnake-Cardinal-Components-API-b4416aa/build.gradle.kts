import com.github.breadmoirai.githubreleaseplugin.GithubReleaseExtension
import java.net.URI

plugins {
    id("net.fabricmc.fabric-loom") version "1.15-SNAPSHOT"
    id("io.github.ladysnake.chenille") version "0.18.0"
}

val fabricApiVersion: String = providers.gradleProperty("fabric_api_version").get()

allprojects {
    apply(plugin = "java-library")
    apply(plugin = "maven-publish")
    apply(plugin = "net.fabricmc.fabric-loom")
    apply(plugin = "io.github.ladysnake.chenille")

    chenille {
        javaVersion = 21
        license = "MIT"
        displayName = providers.gradleProperty("display_name").get()
        owners = providers.gradleProperty("owners").get()
    }

    group = "org.ladysnake.cardinal-components-api"
    version = providers.gradleProperty("mod_version").get()

    repositories {
        maven {
            name = "Ladysnake Mods"
            url = URI("https://maven.ladysnake.org/releases")
            content {
                includeGroup("io.github.ladysnake")
                includeGroup("org.ladysnake")
                includeGroupByRegex("dev\\.emi.*")
                includeGroupByRegex("dev\\.onyxstudios.*")
            }
        }
        maven {
            name = "Ladysnake Mods Snapshots"
            url = URI("https://maven.ladysnake.org/snapshots")
            content {
                includeGroup("org.ladysnake")
            }
        }
        maven {
            name = "Shedaniel"
            url = URI("https://maven.shedaniel.me")
            content {
                includeGroup("me.shedaniel.cloth")
            }
        }
        maven {
            name = "Modrinth"
            url = URI("https://api.modrinth.com/maven")
            content {
                includeGroup("maven.modrinth")
            }
        }
        maven {
            name = "JitPack"
            url = URI("https://jitpack.io")
        }
        mavenLocal()
    }

    dependencies {
        val props = project.properties
        minecraft("com.mojang:minecraft:${props["minecraft_version"]}")
        api("net.fabricmc:fabric-loader:${props["loader_version"]}")
        api(fabricApi.module("fabric-api-base", fabricApiVersion))
        implementation(fabricApi.module("fabric-entity-events-v1", fabricApiVersion))
        implementation(fabricApi.module("fabric-networking-api-v1", fabricApiVersion))
        implementation(fabricApi.module("fabric-lifecycle-events-v1", fabricApiVersion))

        compileOnly(fabricApi.module("fabric-gametest-api-v1", fabricApiVersion))
        localImplementation("org.ladysnake:elmendorf:${props["elmendorf_version"]}")

        compileOnly("org.jetbrains:annotations:24.0.1")
    }

    tasks.processResources {
        inputs.property("version", project.version)

        filesMatching("fabric.mod.json") {
            expand(mapOf("version" to project.version))
        }
    }

    java {
        // Loom will automatically attach sourcesJar to a RemapSourcesJar task and to the "build" task
        // if it is present.
        // If you remove this line, sources will not be generated.
        withSourcesJar()
    }

    tasks.withType<AbstractArchiveTask>().configureEach {
        isPreserveFileTimestamps = false
        isReproducibleFileOrder = true
    }

    tasks.withType<GenerateModuleMetadata>().configureEach {
        enabled = false
    }

    tasks.jar {
        from(rootProject.file("LICENSE.md")) {
            rename { "LICENSE_${project.name.replace("-", "_")}"}
        }
    }
}

tasks.javadoc {
    with (options as StandardJavadocDocletOptions) {
        source = "16"
        encoding = "UTF-8"
        charset("UTF-8")
        memberLevel = JavadocMemberLevel.PACKAGE
        links(
            "https://guava.dev/releases/21.0/api/docs/",
            "https://docs.oracle.com/en/java/javase/21/docs/api/",
            "https://jenkins.liteloader.com/job/Mixin/javadoc/",
            "https://logging.apache.org/log4j/2.x/javadoc/log4j-api/",
        )
        // Disable the crazy super-strict doclint tool in Java 8
        addStringOption("Xdoclint:none", "-quiet")
    }

    allprojects.forEach { p ->
        source(p.sourceSets.main.map { it.allJava.srcDirs })
    }

    classpath = project.files(sourceSets.main.map { it.compileClasspath })
    include("**/api/**")
    isFailOnError = false
}

val javadocJar by tasks.registering(Jar::class) {
    dependsOn(tasks.javadoc)
    from(tasks.javadoc.map { it.destinationDir!! })
    //Set as `fatjavadoc` to prevent an ide from trying to use this javadoc, over using the modules javadoc
    archiveClassifier.set("fatjavadoc")
}

tasks.assemble.configure {
    dependsOn(javadocJar)
}

tasks.test.configure {
    dependsOn(tasks.named("runGametest"))
}

subprojects {
    version = rootProject.version

    sourceSets.create("testmod") {
        compileClasspath += sourceSets.main.get().compileClasspath
        runtimeClasspath += sourceSets.main.get().runtimeClasspath
    }

    dependencies {
        "testmodImplementation"(sourceSets.main.map { it.output })
    }

    extensions.configure(PublishingExtension::class.java) {
        publications {
            create("relocation1", MavenPublication::class.java) {
                pom {
                    // Old artifact coordinates
                    groupId = "io.github.onyxstudios.Cardinal-Components-API"

                    distributionManagement {
                        relocation {
                            // New artifact coordinates
                            groupId = "org.ladysnake.cardinal-components-api"
                            message = "groupId has been changed"
                        }
                    }
                }
            }
            create("relocation2", MavenPublication::class.java) {
                pom {
                    // Old artifact coordinates
                    groupId = "dev.onyxstudios.cardinal-components-api"

                    distributionManagement {
                        relocation {
                            // New artifact coordinates
                            groupId = "org.ladysnake.cardinal-components-api"
                            message = "groupId has been changed"
                        }
                    }
                }
            }
            create("mavenJava", MavenPublication::class.java) {
                from(components.getByName("java"))
            }
        }
    }

    chenille {
        configurePublishing {
            withLadysnakeMaven()
        }
    }

    tasks.javadoc.configure {
        isEnabled = false
    }
}

val mavenJar by tasks.registering(Jar::class) {
    archiveFileName.set("cardinal-components-api-${project.version}-maven.jar")
}

extensions.configure(PublishingExtension::class.java) {
    publications {
        val mavenJava by creating(MavenPublication::class) {
            artifact(mavenJar)

            artifact(tasks.named("sourcesJar"))

            artifact(tasks.named("javadocJar"))

            pom.withXml {
                val depsNode = asNode().appendNode("dependencies")
                subprojects.forEach {
                    val depNode = depsNode.appendNode("dependency")
                    depNode.appendNode("groupId", it.group)
                    depNode.appendNode("artifactId", it.name)
                    depNode.appendNode("version", it.version)
                    depNode.appendNode("scope", "compile")
                }
            }
        }
        // Required until the deprecation is removed. CCA's main jar that is published to maven does not contain sub modules.
        @Suppress("UnstableApiUsage")
        loom.disableDeprecatedPomGeneration(mavenJava)
    }
}

chenille {
    configureTestmod {
        withBaseTestRuns()
    }
    configurePublishing {
        withLadysnakeMaven()
        withCurseforgeRelease()
        withGithubRelease()
        withModrinthRelease()
    }
}

extensions.configure(GithubReleaseExtension::class.java) {
    owner = providers.gradleProperty("owners")
}

dependencies {
    // used by the test mod
    implementation(fabricApi.module("fabric-api-base", fabricApiVersion))
    implementation(fabricApi.module("fabric-object-builder-api-v1", fabricApiVersion))
    implementation(fabricApi.module("fabric-rendering-v1", fabricApiVersion))
    implementation(fabricApi.module("fabric-lifecycle-events-v1", fabricApiVersion))
    implementation(fabricApi.module("fabric-item-api-v1", fabricApiVersion))
    implementation(fabricApi.module("fabric-creative-tab-api-v1", fabricApiVersion))
    implementation(fabricApi.module("fabric-events-interaction-v0", fabricApiVersion))
    implementation(fabricApi.module("fabric-api-lookup-api-v1", fabricApiVersion))
    implementation(fabricApi.module("fabric-command-api-v2", fabricApiVersion))
    implementation(fabricApi.module("fabric-gametest-api-v1", fabricApiVersion))
    runtimeOnly(fabricApi.module("fabric-networking-api-v1", fabricApiVersion))
    runtimeOnly(fabricApi.module("fabric-resource-loader-v0", fabricApiVersion))
    runtimeOnly(fabricApi.module("fabric-events-interaction-v0", fabricApiVersion))
    runtimeOnly(fabricApi.module("fabric-registry-sync-v0", fabricApiVersion))

    testCompileOnly("com.google.code.findbugs:jsr305:3.0.2")

    subprojects.forEach {
        api(project(":${it.name}"))
        include(project("${it.name}:"))
        "testmodImplementation"(it.sourceSets["testmod"].output)
    }
}

val testmodJar by tasks.registering(Jar::class) {
    archiveBaseName.set("CCATest")
    archiveClassifier.set("testmod")
    from(sourceSets["testmod"].output) {
        include("fabric.mod.json")
        expand(mapOf("version" to project.version))
    }
    from(sourceSets["testmod"].output) {
        exclude("fabric.mod.json")
    }
    dependsOn(tasks.named("testmodClasses"))
}

tasks.assemble.configure {
    dependsOn(testmodJar)
}
