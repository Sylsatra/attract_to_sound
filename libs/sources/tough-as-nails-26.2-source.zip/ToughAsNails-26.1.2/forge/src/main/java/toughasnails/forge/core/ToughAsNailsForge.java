/*******************************************************************************
 * Copyright 2021, the Glitchfiend Team.
 * All rights reserved.
 ******************************************************************************/
package toughasnails.forge.core;

import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import toughasnails.core.ToughAsNails;

@Mod(value = ToughAsNails.MOD_ID)
public class ToughAsNailsForge
{
    public ToughAsNailsForge()
    {
        ServerStartingEvent.BUS.addListener(this::serverAboutToStart);
        ToughAsNails.init();
    }

    private void clientSetup(final FMLClientSetupEvent event)
    {
        event.enqueueWork(ToughAsNails::setupClient);
    }

    private void serverAboutToStart(final ServerStartingEvent event)
    {
        ToughAsNails.onServerAboutToStart(event.getServer());
    }
}
